# Pixel Chatmail Messenger

A mobile-first, Google Pixel / Material You inspired messenger starter. Includes username/password registration and login, private contact lists, persistent one-to-one text messages, live message delivery over Socket.IO, and browser WebRTC voice/video calls with peer-to-peer ICE negotiation.

## Run locally

1. Install Node.js 20 or newer.
2. Copy `.env.example` to `.env` and set a long random `SESSION_SECRET`.
3. Run `npm install`.
4. Run `npm start` and open `http://localhost:3000`.

For two-person testing, open the site in two separate browsers/devices, register two accounts, add each other's usernames, then try text and calls. Calls need HTTPS (or localhost) and microphone/camera permission. The current ICE config uses public STUN servers; direct P2P works when network NAT/firewall rules permit it. For reliable calls across restrictive networks, configure a TURN server and add its credentials in `rtcConfig()`.

## Important: Chatmail compatibility status

This starter is **not yet a Delta Chat / Chatmail client**. It currently stores app messages in its own SQLite database. True Chatmail compatibility requires integrating the official Delta Chat Core JSON-RPC runtime (`@deltachat/stdio-rpc-server` + `@deltachat/jsonrpc-client`), configuring a real Chatmail relay/domain, provisioning one Delta Chat profile per user, and routing contacts/messages through that core so Autocrypt/OpenPGP and Chatmail transport semantics are preserved. Do not connect this app to a relay by forwarding raw passwords or implementing SMTP/IMAP encryption yourself.

The `CHATMAIL_DOMAIN` environment variable is reserved for that integration; merely setting it does not enable Chatmail. This is deliberately explicit rather than falsely claiming interoperability.

## Production checklist

- Use HTTPS and set `NODE_ENV=production` plus a strong `SESSION_SECRET`.
- Persist `DATA_DIR` on a durable volume and back up the SQLite database.
- Add TURN credentials for reliable WebRTC calls; do not expose TURN secrets in frontend code.
- Add account recovery, abuse reporting/blocking, retention controls, and monitoring before inviting public users.
- For a public launch, consider PostgreSQL instead of SQLite and add CSRF protection and stricter origin policy.
