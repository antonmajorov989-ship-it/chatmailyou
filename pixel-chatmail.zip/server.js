import 'dotenv/config';
import express from 'express';
import http from 'node:http';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import session from 'express-session';
import SQLiteStoreFactory from 'connect-sqlite3';
import Database from 'better-sqlite3';
import bcrypt from 'bcryptjs';
import helmet from 'helmet';
import { rateLimit } from 'express-rate-limit';
import { Server } from 'socket.io';
import fs from 'node:fs';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const dataDir = path.resolve(process.env.DATA_DIR || './data');
fs.mkdirSync(dataDir, { recursive: true });
const dbFile = path.resolve(process.env.DATABASE_FILE || path.join(dataDir, 'messenger.sqlite'));
const db = new Database(dbFile);
db.pragma('journal_mode = WAL');
db.pragma('foreign_keys = ON');
db.exec(`
CREATE TABLE IF NOT EXISTS users (
 id INTEGER PRIMARY KEY AUTOINCREMENT,
 username TEXT NOT NULL UNIQUE COLLATE NOCASE,
 password_hash TEXT NOT NULL,
 created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS contacts (
 user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
 contact_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
 created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
 PRIMARY KEY(user_id, contact_id), CHECK(user_id <> contact_id)
);
CREATE TABLE IF NOT EXISTS messages (
 id INTEGER PRIMARY KEY AUTOINCREMENT,
 sender_id INTEGER NOT NULL REFERENCES users(id),
 recipient_id INTEGER NOT NULL REFERENCES users(id),
 body TEXT NOT NULL CHECK(length(body) <= 4000),
 created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
 read_at TEXT
);
CREATE INDEX IF NOT EXISTS messages_pair_idx ON messages(sender_id, recipient_id, id);
`);

const app = express();
const server = http.createServer(app);
const io = new Server(server, { cors: { origin: false }, maxHttpBufferSize: 1e5 });
const SQLiteStore = SQLiteStoreFactory(session);
const sessionMiddleware = session({
  store: new SQLiteStore({ db: 'sessions.sqlite', dir: dataDir }),
  secret: process.env.SESSION_SECRET || 'development-only-change-me',
  resave: false,
  saveUninitialized: false,
  cookie: { httpOnly: true, sameSite: 'lax', secure: process.env.NODE_ENV === 'production', maxAge: 7 * 24 * 60 * 60 * 1000 }
});
app.use(helmet({ contentSecurityPolicy: false }));
app.use(express.json({ limit: '20kb' }));
app.use(sessionMiddleware);
app.use(express.static(path.join(__dirname, 'public')));

const authLimiter = rateLimit({ windowMs: 15 * 60 * 1000, limit: 12, standardHeaders: 'draft-7', legacyHeaders: false });
const messageLimiter = rateLimit({ windowMs: 60 * 1000, limit: 90, standardHeaders: 'draft-7', legacyHeaders: false });
const publicUser = u => ({ id: u.id, username: u.username });
const requireAuth = (req, res, next) => req.session.userId ? next() : res.status(401).json({ error: 'Войдите в аккаунт' });
const getUser = id => db.prepare('SELECT id, username FROM users WHERE id = ?').get(id);
const areContacts = (a, b) => !!db.prepare('SELECT 1 FROM contacts WHERE user_id=? AND contact_id=?').get(a, b);

app.get('/api/status', (_req, res) => res.json({ ok: true, chatmailConfigured: Boolean(process.env.CHATMAIL_DOMAIN), calls: 'WebRTC P2P with STUN; TURN can be configured in deployment' }));
app.post('/api/register', authLimiter, async (req, res) => {
  const username = String(req.body.username || '').trim();
  const password = String(req.body.password || '');
  if (!/^[a-zA-Z0-9_]{3,24}$/.test(username)) return res.status(400).json({ error: 'Имя: 3–24 символа, латиница, цифры или _' });
  if (password.length < 10 || password.length > 128) return res.status(400).json({ error: 'Пароль должен содержать от 10 до 128 символов' });
  try {
    const hash = await bcrypt.hash(password, 12);
    const result = db.prepare('INSERT INTO users(username,password_hash) VALUES(?,?)').run(username, hash);
    req.session.userId = Number(result.lastInsertRowid);
    res.json({ user: publicUser(getUser(req.session.userId)) });
  } catch (e) {
    if (String(e).includes('UNIQUE')) return res.status(409).json({ error: 'Это имя уже занято' });
    res.status(500).json({ error: 'Не удалось создать аккаунт' });
  }
});
app.post('/api/login', authLimiter, async (req, res) => {
  const username = String(req.body.username || '').trim();
  const password = String(req.body.password || '');
  const row = db.prepare('SELECT * FROM users WHERE username = ? COLLATE NOCASE').get(username);
  if (!row || !(await bcrypt.compare(password, row.password_hash))) return res.status(401).json({ error: 'Неверное имя пользователя или пароль' });
  req.session.regenerate(err => {
    if (err) return res.status(500).json({ error: 'Не удалось создать сессию' });
    req.session.userId = row.id;
    req.session.save(() => res.json({ user: publicUser(row) }));
  });
});
app.post('/api/logout', requireAuth, (req, res) => req.session.destroy(() => res.json({ ok: true })));
app.get('/api/me', requireAuth, (req, res) => res.json({ user: publicUser(getUser(req.session.userId)) }));

app.post('/api/contacts', requireAuth, (req, res) => {
  const username = String(req.body.username || '').trim();
  const target = db.prepare('SELECT id,username FROM users WHERE username=? COLLATE NOCASE').get(username);
  if (!target) return res.status(404).json({ error: 'Пользователь не найден' });
  if (target.id === req.session.userId) return res.status(400).json({ error: 'Нельзя добавить самого себя' });
  db.prepare('INSERT OR IGNORE INTO contacts(user_id,contact_id) VALUES(?,?)').run(req.session.userId, target.id);
  db.prepare('INSERT OR IGNORE INTO contacts(user_id,contact_id) VALUES(?,?)').run(target.id, req.session.userId);
  res.json({ user: publicUser(target) });
});
app.get('/api/contacts', requireAuth, (req, res) => {
  const rows = db.prepare(`SELECT u.id,u.username FROM contacts c JOIN users u ON u.id=c.contact_id WHERE c.user_id=? ORDER BY u.username`).all(req.session.userId);
  res.json({ contacts: rows });
});
app.get('/api/messages/:peerId', requireAuth, (req, res) => {
  const me = req.session.userId, peer = Number(req.params.peerId);
  if (!Number.isInteger(peer) || !areContacts(me, peer)) return res.status(403).json({ error: 'Сначала добавьте пользователя в контакты' });
  const rows = db.prepare(`SELECT id,sender_id AS senderId,recipient_id AS recipientId,body,created_at AS createdAt FROM messages WHERE (sender_id=? AND recipient_id=?) OR (sender_id=? AND recipient_id=?) ORDER BY id DESC LIMIT 100`).all(me, peer, peer, me).reverse();
  db.prepare('UPDATE messages SET read_at=CURRENT_TIMESTAMP WHERE sender_id=? AND recipient_id=? AND read_at IS NULL').run(peer, me);
  res.json({ messages: rows });
});
app.post('/api/messages', requireAuth, messageLimiter, (req, res) => {
  const sender = req.session.userId, recipient = Number(req.body.recipientId), body = String(req.body.body || '').trim();
  if (!Number.isInteger(recipient) || !areContacts(sender, recipient)) return res.status(403).json({ error: 'Контакт не найден' });
  if (!body || body.length > 4000) return res.status(400).json({ error: 'Сообщение должно быть от 1 до 4000 символов' });
  const result = db.prepare('INSERT INTO messages(sender_id,recipient_id,body) VALUES(?,?,?)').run(sender, recipient, body);
  const message = db.prepare('SELECT id,sender_id AS senderId,recipient_id AS recipientId,body,created_at AS createdAt FROM messages WHERE id=?').get(result.lastInsertRowid);
  io.to(`user:${recipient}`).emit('message:new', message);
  io.to(`user:${sender}`).emit('message:new', message);
  res.json({ message });
});

io.engine.use(sessionMiddleware);
io.use((socket, next) => {
  const userId = socket.request.session?.userId;
  if (!userId) return next(new Error('unauthorized'));
  socket.userId = userId;
  next();
});
io.on('connection', socket => {
  socket.join(`user:${socket.userId}`);
  socket.on('call:signal', payload => {
    const to = Number(payload?.to);
    const type = payload?.type;
    if (!Number.isInteger(to) || !areContacts(socket.userId, to)) return;
    if (!['offer', 'answer', 'ice', 'hangup', 'busy'].includes(type)) return;
    const data = { from: socket.userId, type, description: payload.description, candidate: payload.candidate, mode: payload.mode };
    io.to(`user:${to}`).emit('call:signal', data);
  });
});

app.get('*', (_req, res) => res.sendFile(path.join(__dirname, 'public', 'index.html')));
const port = Number(process.env.PORT || 3000);
server.listen(port, '0.0.0.0', () => console.log(`Pixel Chatmail listening on :${port}`));
